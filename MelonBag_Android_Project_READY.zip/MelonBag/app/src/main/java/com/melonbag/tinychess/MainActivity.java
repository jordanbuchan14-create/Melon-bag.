package com.melonbag.tinychess;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.*;
import android.graphics.drawable.ColorDrawable;
import android.view.*;
import android.content.Context;
import android.media.AudioManager;
import android.media.ToneGenerator;
import java.util.*;

public class MainActivity extends Activity {
    GameView game;
    @Override public void onCreate(Bundle b){ super.onCreate(b); getWindow().setFlags(1024,1024); game=new GameView(this); setContentView(game); }
    @Override protected void onPause(){ super.onPause(); game.pause(); }
    @Override protected void onResume(){ super.onResume(); if(game!=null) game.resume(); }
}

class GameView extends View {
    Paint p=new Paint(3); Random rng=new Random(); ToneGenerator tone;
    int W,H,cell,cols,rows,level=1,score=0,goal=6,state=0; // 0 title,1 playing,2 gameover,3 complete
    int px,py,dx=1,dy=0,ndx=1,ndy=0; float anim=0,last;
    ArrayList<Point> body=new ArrayList<>(), melons=new ArrayList<>(), obstacles=new ArrayList<>();
    float sx,sy;
    GameView(Context c){super(c); p.setTypeface(Typeface.create("sans",Typeface.BOLD)); tone=new ToneGenerator(AudioManager.STREAM_MUSIC,65); setFocusable(true);}
    void pause(){ }
    void resume(){ last=System.currentTimeMillis(); postInvalidate(); }
    void setup(){ W=getWidth(); H=getHeight(); cell=Math.max(48,Math.min(76,W/8)); cols=W/cell+2; rows=H/cell+2; }
    void startLevel(){ setup(); state=1; score=0; goal=4+level*2; body.clear();melons.clear();obstacles.clear();px=cols/2;py=rows/2;dx=1;dy=0;ndx=1;ndy=0; for(int i=0;i<3+Math.min(level,7);i++)spawnMelon(); for(int i=0;i<Math.min(level-1,8);i++)spawnObstacle(); last=System.currentTimeMillis(); }
    boolean occupied(int x,int y){ if(x==px&&y==py)return true; for(Point q:melons)if(q.x==x&&q.y==y)return true;for(Point q:obstacles)if(q.x==x&&q.y==y)return true;return false; }
    Point freePoint(){ Point q; int tries=0; do{q=new Point(1+rng.nextInt(Math.max(1,cols-2)),1+rng.nextInt(Math.max(1,rows-2)));}while(occupied(q.x,q.y)&&tries++<500);return q; }
    void spawnMelon(){melons.add(freePoint());}
    void spawnObstacle(){obstacles.add(freePoint());}
    void beep(int kind){try{ if(kind==1){tone.startTone(ToneGenerator.TONE_PROP_BEEP,55);} else if(kind==2){tone.startTone(ToneGenerator.TONE_PROP_ACK,80);} else tone.startTone(ToneGenerator.TONE_PROP_NACK,140);}catch(Exception e){}}
    void step(){ dx=ndx;dy=ndy; body.add(0,new Point(px,py)); px+=dx;py+=dy; anim+=Math.PI/2;
        boolean bad=px<1||py<1||px>cols-2||py>rows-2; for(int i=3;i<body.size()&&!bad;i++)if(body.get(i).x==px&&body.get(i).y==py)bad=true; for(Point q:obstacles)if(q.x==px&&q.y==py)bad=true;
        if(bad){state=2;beep(3);invalidate();return;}
        for(int i=0;i<melons.size();i++)if(melons.get(i).x==px&&melons.get(i).y==py){melons.remove(i);score++;beep(2);spawnMelon();break;}
        if(body.size()>score)body.remove(body.size()-1); if(score>=goal){state=3;beep(2);} invalidate(); }
    @Override protected void onDraw(Canvas c){super.onDraw(c); setup(); drawBoard(c); if(state==0)drawTitle(c); else if(state==2)drawGameOver(c); else if(state==3)drawComplete(c); else drawHud(c); long now=System.currentTimeMillis(); if(state==1&&now-last>145){last=now;step();} postInvalidateDelayed(16); }
    void drawBoard(Canvas c){ for(int y=0;y<rows;y++)for(int x=0;x<cols;x++){p.setColor(((x+y)&1)==0?Color.rgb(77,118,80):Color.rgb(216,178,120));c.drawRect(x*cell-cell,y*cell-cell,(x+1)*cell+1,(y+1)*cell+1,p);} p.setTextAlign(Paint.Align.CENTER);p.setTextSize(cell*.65f);p.setColor(Color.argb(70,255,255,255)); c.drawText("♜",cell,cell,p);c.drawText("♞",(cols-2)*cell,cell,p);c.drawText("♟",2*cell,(rows-2)*cell,p);c.drawText("♛",(cols-3)*cell,(rows-2)*cell,p);
        for(Point q:obstacles){p.setColor(Color.rgb(150,88,39));c.drawRect(q.x*cell-cell*.24f,q.y*cell-cell*.24f,q.x*cell+cell*.24f,q.y*cell+cell*.24f,p);p.setColor(Color.rgb(214,155,82));c.drawRect(q.x*cell-cell*.14f,q.y*cell-cell*.15f,q.x*cell+cell*.14f,q.y*cell-cell*.07f,p);}
        for(Point q:melons){float x=q.x*cell,y=q.y*cell,r=cell*.23f;p.setColor(Color.rgb(113,166,57));c.drawCircle(x,y,r,p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2);p.setColor(Color.rgb(42,78,32));c.drawCircle(x,y,r,p);p.setStyle(Paint.Style.FILL);p.setColor(Color.rgb(48,90,43));c.drawRect(x+r*.5f,y-r*.75f,x+r*.62f,y-r*.45f,p);}
        for(int i=body.size()-1;i>=0;i--)drawMan(c,body.get(i),.62f,i); drawMan(c,new Point(px,py),1,0);
        p.setColor(Color.argb(120,0,0,0));c.drawRect(0,0,W,H,p); // vignette-like overlay
    }
    void drawMan(Canvas c,Point q,float scale,int index){float x=q.x*cell,y=q.y*cell;float bob=index==0?(float)Math.sin(anim)*cell*.04f:0;float swing=index==0?(float)Math.sin(anim)*cell*.07f:0;p.setStyle(Paint.Style.FILL);c.save();c.translate(x,y+bob);c.scale(scale,scale);
        p.setColor(Color.rgb(30,30,38));p.setStrokeWidth(cell*.1f);p.setStrokeCap(Paint.Cap.ROUND);c.drawLine(-cell*.07f,cell*.25f,-cell*.1f+swing,cell*.45f,p);c.drawLine(cell*.07f,cell*.25f,cell*.1f-swing,cell*.45f,p);
        float bag=1+Math.min(body.size(),16)*.035f;p.setColor(Color.rgb(111,69,31));c.drawOval(-cell*.25f*bag,cell*.02f,cell*.25f*bag,cell*.55f*bag,p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3);p.setColor(Color.rgb(198,136,67));c.drawOval(-cell*.25f*bag,cell*.02f,cell*.25f*bag,cell*.55f*bag,p);p.setStyle(Paint.Style.FILL);
        p.setColor(Color.rgb(51,75,94));c.drawRect(-cell*.15f,-cell*.03f,cell*.15f,cell*.3f,p);p.setColor(Color.rgb(232,178,123));p.setStrokeWidth(cell*.075f);c.drawLine(-cell*.12f,0,-cell*.24f,cell*.18f,p);c.drawLine(cell*.12f,0,cell*.24f,cell*.18f,p);c.drawCircle(0,-cell*.2f,cell*.17f,p);p.setColor(Color.rgb(43,32,25));c.drawArc(-cell*.17f,-cell*.37f,cell*.17f,-cell*.03f,180,-180,true,p);p.setColor(Color.WHITE);c.drawRect(-cell*.075f,-cell*.22f,-cell*.03f,-cell*.185f,p);c.drawRect(cell*.03f,-cell*.22f,cell*.075f,-cell*.185f,p);c.restore(); }
    void panel(Canvas c,String title,String sub,String button){p.setColor(Color.argb(215,18,30,23));c.drawRoundRect(W*.08f,H*.22f,W*.92f,H*.78f,30,30,p);p.setTextAlign(Paint.Align.CENTER);p.setColor(Color.WHITE);p.setTextSize(Math.min(54,W*.11f));c.drawText(title,W/2,H*.38f,p);p.setTextSize(18);p.setColor(Color.argb(220,255,255,255));c.drawText(sub,W/2,H*.47f,p);p.setColor(Color.rgb(217,192,109));c.drawRoundRect(W*.25f,H*.58f,W*.75f,H*.68f,18,18,p);p.setColor(Color.rgb(25,32,22));p.setTextSize(18);c.drawText(button,W/2,H*.645f,p);}
    void drawTitle(Canvas c){panel(c,"🍈 MELON BAG","Tiny man. Giant chessboard.\nVery large bag.","START GAME");}
    void drawGameOver(Canvas c){panel(c,"BAG SPILLED!","Level "+level+" • Melons: "+score,"RESTART LEVEL");}
    void drawComplete(Canvas c){panel(c,"LEVEL COMPLETE!","Level "+level+" cleared • Bag size "+(score+1),"NEXT LEVEL");}
    void drawHud(Canvas c){p.setTextAlign(Paint.Align.LEFT);p.setTextSize(17);p.setColor(Color.WHITE);p.setShadowLayer(4,0,2,Color.BLACK);c.drawText("🍈 "+score+" / "+goal,14,30,p);p.setTextAlign(Paint.Align.RIGHT);c.drawText("LEVEL "+level,W-14,30,p);p.clearShadowLayer();}
    @Override public boolean onTouchEvent(android.view.MotionEvent e){if(e.getAction()==MotionEvent.ACTION_DOWN){sx=e.getX();sy=e.getY();return true;} if(e.getAction()==MotionEvent.ACTION_UP){float ax=e.getX()-sx,ay=e.getY()-sy;
        if(state==0){if(Math.abs(ax)<80&&Math.abs(ay)<80){level=1;startLevel();}return true;} if(state==2){if(Math.abs(ax)<80&&Math.abs(ay)<80)startLevel();return true;} if(state==3){if(Math.abs(ax)<80&&Math.abs(ay)<80){level++;startLevel();}return true;}
        if(Math.max(Math.abs(ax),Math.abs(ay))>20){if(Math.abs(ax)>Math.abs(ay)){if(ax>0&&dx!=-1){ndx=1;ndy=0;}else if(ax<0&&dx!=1){ndx=-1;ndy=0;}}else{if(ay>0&&dy!=-1){ndx=0;ndy=1;}else if(ay<0&&dy!=1){ndx=0;ndy=-1;}}} return true;}return true; }
}
